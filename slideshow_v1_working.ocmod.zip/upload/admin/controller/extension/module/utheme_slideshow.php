<?php
class ControllerExtensionModuleuthemeSlideshow extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/module/utheme_slideshow');

		$this->document->setTitle($this->language->get('extension_title'));

		$this->load->model('setting/module');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			if (!isset($this->request->get['module_id'])) {
				$this->model_setting_module->addModule('utheme_slideshow', $this->request->post);
			} else {
				$this->model_setting_module->editModule($this->request->get['module_id'], $this->request->post);
			}

			$this->session->data['success'] = $this->language->get('text_success');

		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		}

		if (isset($this->error['width'])) {
			$data['error_desktop_width'] = $this->error['width'];
		} else {
			$data['error_desktop_width'] = '';
		}

		if (isset($this->error['height'])) {
			$data['error_desktop_height'] = $this->error['height'];
		} else {
			$data['error_desktop_height'] = '';
    }

    if (isset($this->error['width'])) {
			$data['error_mobile_width'] = $this->error['width'];
		} else {
			$data['error_mobile_width'] = '';
		}

		if (isset($this->error['height'])) {
			$data['error_mobile_height'] = $this->error['height'];
		} else {
			$data['error_mobile_height'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);

		if (!isset($this->request->get['module_id'])) {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('extension_title'),
				'href' => $this->url->link('extension/module/utheme_slideshow', 'user_token=' . $this->session->data['user_token'], true)
			);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('extension_title'),
				'href' => $this->url->link('extension/module/utheme_slideshow', 'user_token=' . $this->session->data['user_token'] . '&module_id=' . $this->request->get['module_id'], true)
			);
		}

		if (!isset($this->request->get['module_id'])) {
			$data['action'] = $this->url->link('extension/module/utheme_slideshow', 'user_token=' . $this->session->data['user_token'], true);
		} else {
			$data['action'] = $this->url->link('extension/module/utheme_slideshow', 'user_token=' . $this->session->data['user_token'] . '&module_id=' . $this->request->get['module_id'], true);
		}

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

		if (isset($this->request->get['module_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$module_info = $this->model_setting_module->getModule($this->request->get['module_id']);
		}

		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($module_info)) {
			$data['name'] = $module_info['name'];
		} else {
			$data['name'] = '';
		}

		if (isset($this->request->post['desktop_width'])) {
			$data['desktop_width'] = $this->request->post['desktop_width'];
		} elseif (!empty($module_info)) {
			$data['desktop_width'] = $module_info['desktop_width'];
		} else {
			$data['desktop_width'] = 1160;
		}

		if (isset($this->request->post['desktop_height'])) {
			$data['desktop_height'] = $this->request->post['desktop_height'];
		} elseif (!empty($module_info)) {
			$data['desktop_height'] = $module_info['desktop_height'];
		} else {
			$data['desktop_height'] = 580;
    }

    if (isset($this->request->post['mobile_width'])) {
			$data['mobile_width'] = $this->request->post['mobile_width'];
		} elseif (!empty($module_info)) {
			$data['mobile_width'] = $module_info['mobile_width'];
		} else {
			$data['mobile_width'] = 560;
		}

		if (isset($this->request->post['mobile_height'])) {
			$data['mobile_height'] = $this->request->post['mobile_height'];
		} elseif (!empty($module_info)) {
			$data['mobile_height'] = $module_info['mobile_height'];
		} else {
			$data['mobile_height'] = 560;
		}

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($module_info)) {
			$data['status'] = $module_info['status'];
		} else {
			$data['status'] = '';
		}

		// Languages 
		$this->load->model('localisation/language');
		$data['languages'] = $this->model_localisation_language->getLanguages();

		// Images
		if (isset($this->request->post['images'])) {
			$images = $this->request->post['images'];
		} elseif (!empty($module_info['images'])) {
			$images = $module_info['images'];
		} else {
			$images = array();
		}

		$this->load->model('tool/image');
		$data['images'] = array();

		foreach ($images as $key => $value) {
			foreach ($value as $image) {

				// Desktop
				if (is_file(DIR_IMAGE . $image['image_d'])) {
					$image_d = $image['image_d'];
					$thumb_d = $image['image_d'];
				} else {
					$image_d = '';
					$thumb_d = 'no_image.png';
				}

				// Mobile
				if (is_file(DIR_IMAGE . $image['image_m'])) {
					$image_m = $image['image_m'];
					$thumb_m = $image['image_m'];
				} else {
					$image_m = '';
					$thumb_m = 'no_image.png';
				}
				
				$data['images'][$key][] = array(
					'title'      => isset($image['title']) ? $image['title'] : '',
					'link'       => isset($image['link']) ? $image['link'] : '',
					'image_d'    => $image_d,
					'thumb_d'    => $this->model_tool_image->resize($thumb_d, 100, 100),
					'image_m'    => $image_m,
					'thumb_m'    => $this->model_tool_image->resize($thumb_m, 100, 100),
					'sort_order' => isset($image['sort_order']) ? $image['sort_order'] : 0,
				);
			}
		}

		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/utheme_slideshow', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/utheme_slideshow')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 64)) {
			$this->error['name'] = $this->language->get('error_name');
		}

		if (!$this->request->post['desktop_width']) {
			$this->error['desktop_width'] = $this->language->get('error_width');
    }

    if (!$this->request->post['desktop_height']) {
			$this->error['desktop_height'] = $this->language->get('error_width');
    }

    if (!$this->request->post['mobile_width']) {
			$this->error['mobile_width'] = $this->language->get('error_width');
    }

    if (!$this->request->post['mobile_height']) {
			$this->error['mobile_height'] = $this->language->get('error_width');
		}

		return !$this->error;
	}
}
