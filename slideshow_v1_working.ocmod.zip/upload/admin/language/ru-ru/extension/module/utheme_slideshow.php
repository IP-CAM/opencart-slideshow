<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']   = '<b style="color: #FF0016;">Utheme</b> Слайдшоу';
$_['extension_title'] = 'Слайдшоу';

// Text
$_['text_module']      = 'Модули';
$_['text_success']     = 'Настройки успешно изменены!';
$_['text_edit']        = 'Редактирование';


// Entry
$_['entry_status']     = 'Статус';
$_['entry_name']       = 'Название модуля';
$_['entry_desktop']    = 'Для ПК и ноутбуков (ШхВ)';
$_['entry_mobile']     = 'Для смартфонов (ШхВ)';
$_['entry_title']      = 'Заголовок (alt)';
$_['entry_link']       = 'Ссылка';
$_['entry_image_d']    = 'Изображение (декст.)';
$_['entry_image_m']    = 'Изображение (моб.)';
$_['entry_sort_order'] = 'Сорт.';

// Error
$_['error_permission'] = 'У вас недостаточно прав для внесения изменений!';
$_['error_name']       = 'Название должно содержать от 3 до 64 символов!';
$_['error_width']      = 'Укажите ширину!';
$_['error_height']     = 'Укажите высоту!';