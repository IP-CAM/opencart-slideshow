<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']   = '<b style="color: #FF0016;">Utheme</b> Slideshow';
$_['extension_title'] = 'Slideshow';

// Text
$_['text_extension']	        = 'Extensions';
$_['text_success']		        = 'Settings changed successfully!';
$_['text_edit']				        = 'Module settings';

// Entry
$_['entry_status'] = 'Status';
$_['entry_name'] = 'Module Name';
$_['entry_desktop'] = 'For PC and Laptops (WxH)';
$_['entry_mobile'] = 'For smartphones (WxH)';
$_['entry_title'] = 'Title (alt)';
$_['entry_link'] = 'Link';
$_['entry_image_d'] = 'Image (dext.)';
$_['entry_image_m'] = 'Image (mobile)';
$_['entry_sort_order'] = 'Sort.';

// Error
$_['error_permission'] = 'You do not have sufficient permissions to make changes!';
$_['error_name'] = 'The name must contain from 3 to 64 characters!';
$_['error_width'] = 'Specify the width!';
$_['error_height'] = 'Specify the height!';