<?php
class ControllerExtensionModuleuthemeSlideshow extends Controller {
	public function index($setting) {
		static $module = 0;

		$this->load->model('design/banner');
    $this->load->model('tool/image');

		$this->load->language('common/icon');
		
		$this->document->addScript('catalog/view/javascript/tiny-slider/tiny-slider.js');
		$this->document->addStyle('catalog/view/javascript/tiny-slider/tiny-slider.css');

		$language_id = $this->config->get('config_language_id');

		if (!empty($setting['images'][$language_id])) {

			foreach ($setting['images'][$language_id] as $image) {
				if (is_file(DIR_IMAGE.$image['image_d']) and is_file(DIR_IMAGE.$image['image_m'])) {
					$data['banners'][] = array(
						'title' => isset($image['title']) ? $image['title'] : '',
						'href'  => isset($image['link']) ? $image['link'] : '',
						'image' => $this->model_tool_image->resize($image['image_d'], $setting['desktop_width'], $setting['desktop_height']),
						'mobile' => $this->model_tool_image->resize($image['image_m'], $setting['mobile_width'], $setting['mobile_height'])
					);
				}
			}
		}


		$data['module'] = $module++;

		return $this->load->view('extension/module/utheme_slideshow', $data);
	}
}